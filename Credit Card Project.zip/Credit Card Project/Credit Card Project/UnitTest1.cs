using System;
using Xunit;

namespace Credit_Card_Project
{
    public class UnitTest1
    {
        [Fact]
        public void Test()
        {
            CreditCardProject.CreditCard first = new CreditCardProject.CreditCard();
            first.Person = "Bob";
            first.Wallet = "Bob's Wallet";
            first.Visa = 100;
            first.Discover = 100;
            first.MasterCard = 100;
            first.GetDiscoverInterest(first.Discover);
            first.GetMasterCardInterest(first.MasterCard);
            first.GetVisaInterest(first.Visa);
            first.TotalWalletInterest(first.Visa, first.MasterCard, first.Discover);
            first.TotalPersonInterest(first.TotalWalletInterest(first.Visa, first.MasterCard, first.Discover));

            Assert.Equal(1, first.GetDiscoverInterest(first.Discover));
            Assert.Equal(10, first.GetVisaInterest(first.Visa));
            Assert.Equal(5, first.GetMasterCardInterest(first.MasterCard));
            Assert.Equal(16, first.TotalWalletInterest(first.Visa, first.MasterCard, first.Discover));
            Assert.Equal(16, first.TotalPersonInterest(first.TotalWalletInterest(first.Visa, first.MasterCard, first.Discover)));
           
        }
        [Fact]
        public void Test2()
        {
            CreditCardProject.CreditCard secondA = new CreditCardProject.CreditCard();
            CreditCardProject.CreditCard secondB = new CreditCardProject.CreditCard();
            secondA.Person = "Jane";
            secondB.Person = secondA.Person;
            secondA.Wallet = "Jane's First Wallet";
            secondA.Visa = 100;
            secondA.Discover = 100;
            secondA.GetVisaInterest(secondA.Visa);
            secondA.GetDiscoverInterest(secondA.Discover);
            secondA.TotalWalletInterest(secondA.Visa, secondA.Discover);
            secondB.Wallet = "Janes' Second Wallet";
            secondB.MasterCard = 100;
            secondB.GetMasterCardInterest(secondB.MasterCard);
            secondB.TotalWalletInterest(secondB.MasterCard);
            secondA.TotalPersonInterest(secondA.TotalWalletInterest(secondA.Visa, secondA.Discover), secondB.TotalWalletInterest(secondB.MasterCard));

            Assert.Equal(11, secondA.TotalWalletInterest(secondA.Visa, secondA.Discover));
            Assert.Equal(5, secondB.TotalWalletInterest(secondB.MasterCard));
            Assert.Equal(16, secondA.TotalPersonInterest(secondA.TotalWalletInterest(secondA.Visa, secondA.Discover), secondB.TotalWalletInterest(secondB.MasterCard)));


        }

        [Fact]
        public void Test3()
        {
            CreditCardProject.CreditCard third = new CreditCardProject.CreditCard();
            CreditCardProject.CreditCard fourth = new CreditCardProject.CreditCard();
            third.Person = "Roy";
            third.Wallet = "Roy's Wallet";
            third.MasterCard = 100;
            third.Visa = 100;
            third.GetMasterCardInterest(third.MasterCard);
            third.GetVisaInterest(third.Visa);
            third.TotalWalletInterest(third.MasterCard, third.Visa);
            third.TotalPersonInterest(third.TotalWalletInterest(third.MasterCard, third.Visa));
            fourth.Person = "Wilma";
            fourth.Wallet = "Wilma's Wallet";
            fourth.Visa = 100;
            fourth.MasterCard = 100;
            fourth.GetVisaInterest(fourth.Visa);
            fourth.GetMasterCardInterest(fourth.MasterCard);
            fourth.TotalWalletInterest(fourth.Visa, fourth.MasterCard);
            fourth.TotalPersonInterest(fourth.TotalWalletInterest(fourth.Visa, fourth.MasterCard));


            Assert.Equal(15, third.TotalWalletInterest(third.MasterCard, third.Visa));
            Assert.Equal(15, third.TotalPersonInterest(third.TotalWalletInterest(third.MasterCard, third.Visa)));
            Assert.Equal(15, fourth.TotalWalletInterest(fourth.Visa, fourth.MasterCard));
            Assert.Equal(15, fourth.TotalPersonInterest(fourth.TotalWalletInterest(fourth.Visa, fourth.MasterCard)));


        }
        
    }
}
