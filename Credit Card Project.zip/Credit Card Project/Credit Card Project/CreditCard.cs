﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CreditCardProject
{
    public class CreditCard
    {
        #region Properties
        private string _Person;
        private string _Wallet;
        private int _MasterCard;
        private int _Discover;
        private int _Visa;

        public string Person { get; set; }
        public string Wallet { get; set; }
        public double MasterCard { get; set; }
        public double Visa { get; set; }
        public double Discover { get; set; }


        #endregion

        #region Methods
        public double GetVisaInterest(double Visa)
        {
            double visaInterest = this.Visa * .10;
            return visaInterest;
        }

        public double GetMasterCardInterest(double MasterCard)
        {
            double mcInterest = this.MasterCard * .05;
            return mcInterest;
        }

        public double GetDiscoverInterest(double Discover)
        {
            double discoverInterest = this.Discover * .01;
            return discoverInterest;
        }

        public double TotalWalletInterest(double Visa = 0, double MasterCard = 0, double Discover = 0)
        {
            double sum = GetVisaInterest(this.Visa) + GetMasterCardInterest(this.MasterCard) + GetDiscoverInterest(this.Discover);
            return sum;
        }

        public double TotalPersonInterest(double TotalWalletInterest1 = 0, double TotalWalletInterest2 = 0)
        {
            double totalInterest = TotalWalletInterest1 + TotalWalletInterest2;
            return totalInterest;
        }
        #endregion
    }
}
